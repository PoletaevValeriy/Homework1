let a = 20;
alert(a); // Задание 1 

let year = prompt ('Год выпуска первого iPhone');
alert(year); // Задание 2

let name = prompt('Имя создателя языка JavaScript.');
alert(name); // Задание 3

let number1 = 10;
let number2 = 2;
alert(number1+number2);
alert(number1-number2);
alert(number1*number2);
alert(number1/number2); // задание 4

let number3 = 2;
let number4 = 5;
let result = number3**number4;
alert(result); // Задание 5

let a1 = 9;
let b1 = 2;
alert(a1%b1);// Задание 6

let num = 1;
alert(num + 5)
alert(num - 3)
alert(num * 7)
alert(num / 3)
alert(++num)
alert(--num)
alert(num)// Задание 7

let age = prompt('Сколько вам лет?');
alert (age); // Задание 8

const user = {
    name: 'Evgrat',
    age: 28,
    isAdmin: false,
}
user ['city of residence'] = true;
user.age=29;
delete ['city of residence'];
let info = prompt('Какую информацию хотите узнать о пользователе?');
alert((user[info])); // Задание 9

let name1 = prompt('Как, Вас зовут?');
alert ('Привет ' + name1 + ' !') // Задание 10










